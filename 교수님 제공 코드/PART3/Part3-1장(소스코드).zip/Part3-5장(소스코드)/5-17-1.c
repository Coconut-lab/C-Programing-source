/* 5-17-1.c 
int a=6, int b=3;
*/