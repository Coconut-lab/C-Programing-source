/*  myheader1.h  
{
	printf("Hello C \n");
*/