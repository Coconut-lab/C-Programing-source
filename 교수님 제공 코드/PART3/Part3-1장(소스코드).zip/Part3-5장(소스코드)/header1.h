/*  header1.h  
#ifndef HEADER_H
	#define HEADER_H
	{
			printf("Hello C \n");
#endif
*/